package com.cg.ui;
import java.util.Scanner;

import org.apache.log4j.Logger;
import org.apache.log4j.PropertyConfigurator;

public class BankClient {
	
	static Scanner sc=new Scanner(System.in);
	static Logger log=null;

	
	public static void main(String[] args) {
		PropertyConfigurator.configure("resources/log4j.properties");
		Logger log = Logger.getRootLogger();
		
		System.out.println("**********WELCOME TO ABC BANK***********");
		System.out.println("");
		System.out.println("          1.Account Holder              ");
		System.out.println("          2.Admin                       ");
		System.out.println("****************************************");
		System.out.println("Enter your option:");
		 int option=sc.nextInt();
		
		switch (option) {
		case 1://Get login details
			log.info(option);
			System.out.println("1.SignIn");
			//System.out.println("2.Signup");
			System.out.println("Enter your choice:");
			 int choice=sc.nextInt();
			  switch (choice) {
			  
			case 1://Signin 
				log.info(choice);
				System.out.println("Login id:");
				String loginid=sc.next();
				System.out.println("Password:");
				String pass=sc.next();
				break;
			case 2://Signup
				log.info(choice);
				System.out.println("Enter Account holder name:");
				String name=sc.next();
				System.out.println("Enter Address:");
				String addres=sc.next();
				System.out.println("Enter Mobile num:");
				String mno=sc.next();
				System.out.println("Enter EmailId:");
				String mail=sc.next();
				System.out.println("Enter Account type:");
				System.out.println("1.Savings");
				System.out.println("2.Current");
				System.out.println("option:");
				int option1=sc.nextInt();
				switch (option1) {
				case 1:
					log.info(option1);
					System.out.println("Savings account created");
					
					break;
				case 2:
					log.info(option1);
					System.out.println("Current account created");
					break;

				default:
					break;
				}
				
				
				
				break;

			default:
				break;
			}
			
			
			break;
			
		case 2:
			
			break;

		default:
			break;
		}
	}
	

}
