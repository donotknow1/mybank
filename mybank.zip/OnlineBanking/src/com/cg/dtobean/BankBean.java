package com.cg.dtobean;

public class BankBean
{
	//account master
	private int accountHolderId;
	private String accountType;
	private int accountBalance;
	private String openingDate;
	
	
	
	
	
	public int getAccountHolderId() {
		return accountHolderId;
	}
	public void setAccountHolderId(int accountHolderId) {
		this.accountHolderId = accountHolderId;
	}
	public String getAccountType() {
		return accountType;
	}
	public void setAccountType(String accountType) {
		this.accountType = accountType;
	}
	public int getAccountBalance() {
		return accountBalance;
	}
	public void setAccountBalance(int accountBalance) {
		this.accountBalance = accountBalance;
	}
	public String getOpeningDate() {
		return openingDate;
	}
	public void setOpeningDate(String openingDate) {
		this.openingDate = openingDate;
	}
	public BankBean(int accountHolderId, String accountType, int accountBalance, String openingDate) {
		super();
		this.accountHolderId = accountHolderId;
		this.accountType = accountType;
		this.accountBalance = accountBalance;
		this.openingDate = openingDate;
	}
	public BankBean() {
		super();
		// TODO Auto-generated constructor stub
	}
	@Override
	public String toString() {
		return "BankBean [accountHolderId=" + accountHolderId + ", accountType=" + accountType + ", accountBalance="
				+ accountBalance + ", openingDate=" + openingDate + "]";
	}
	
	


	
	
	
	
	
}
