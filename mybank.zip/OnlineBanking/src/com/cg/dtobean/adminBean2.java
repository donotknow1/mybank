package com.cg.dtobean;

public class adminBean2 {
	
	//transactions
	private int transactionId;
	private String transactionDescription;
	private String transcationDate;
	private String transcationType;
	private int transcationAmount;
	private String AccountNumber;
	public int getTransactionId() {
		return transactionId;
	}
	public void setTransactionId(int transactionId) {
		this.transactionId = transactionId;
	}
	public String getTransactionDescription() {
		return transactionDescription;
	}
	public void setTransactionDescription(String transactionDescription) {
		this.transactionDescription = transactionDescription;
	}
	public String getTranscationDate() {
		return transcationDate;
	}
	public void setTranscationDate(String transcationDate) {
		this.transcationDate = transcationDate;
	}
	public String getTranscationType() {
		return transcationType;
	}
	public void setTranscationType(String transcationType) {
		this.transcationType = transcationType;
	}
	public int getTranscationAmount() {
		return transcationAmount;
	}
	public void setTranscationAmount(int transcationAmount) {
		this.transcationAmount = transcationAmount;
	}
	public String getAccountNumber() {
		return AccountNumber;
	}
	public void setAccountNumber(String accountNumber) {
		AccountNumber = accountNumber;
	}
	public adminBean2() {
		super();
		// TODO Auto-generated constructor stub
	}
	public adminBean2(int transactionId, String transactionDescription, String transcationDate, String transcationType,
			int transcationAmount, String accountNumber) {
		super();
		this.transactionId = transactionId;
		this.transactionDescription = transactionDescription;
		this.transcationDate = transcationDate;
		this.transcationType = transcationType;
		this.transcationAmount = transcationAmount;
		AccountNumber = accountNumber;
	}
	
	
	
	
}
