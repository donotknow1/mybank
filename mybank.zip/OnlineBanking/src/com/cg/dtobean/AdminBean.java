package com.cg.dtobean;

public class AdminBean {

	
	//service_tracker
	private int serviceID ;
	private String serviceDescription ;
	private int accountId1 ;
	private String serviceRaisedDate ;
	private String serviceStatus;
	
	
	//user_table
		private int accountId; 
		private int userId ;
		private String loginPassword;
		private String secretQuestion ;
		private String	transactionPassword;
		private String	lockStatus;
	
}
