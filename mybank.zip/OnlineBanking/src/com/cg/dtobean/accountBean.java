package com.cg.dtobean;

public class accountBean {
	//payee_table
		private int accountId;
		private int	payeeAccountId ;
		private String	nickName ;
		public int getAccountId() {
			return accountId;
		}
		public void setAccountId(int accountId) {
			this.accountId = accountId;
		}
		public int getPayeeAccountId() {
			return payeeAccountId;
		}
		public void setPayeeAccountId(int payeeAccountId) {
			this.payeeAccountId = payeeAccountId;
		}
		public String getNickName() {
			return nickName;
		}
		public void setNickName(String nickName) {
			this.nickName = nickName;
		}
		public accountBean(int accountId, int payeeAccountId, String nickName) {
			super();
			this.accountId = accountId;
			this.payeeAccountId = payeeAccountId;
			this.nickName = nickName;
		}
		public accountBean() {
			super();
			// TODO Auto-generated constructor stub
		}

		
		
}
