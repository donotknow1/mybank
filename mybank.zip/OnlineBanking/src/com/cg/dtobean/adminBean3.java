package com.cg.dtobean;

public class adminBean3 {
	
	// Fund_transfer
	private int fundTransferID ;
	private int accountId ;
	private int payeeAccountID;
	private String dateOfTransfer;
	private int transferAmount;
	public int getFundTransferID() {
		return fundTransferID;
	}
	public void setFundTransferID(int fundTransferID) {
		this.fundTransferID = fundTransferID;
	}
	public int getAccountId() {
		return accountId;
	}
	public void setAccountId(int accountId) {
		this.accountId = accountId;
	}
	public int getPayeeAccountID() {
		return payeeAccountID;
	}
	public void setPayeeAccountID(int payeeAccountID) {
		this.payeeAccountID = payeeAccountID;
	}
	public String getDateOfTransfer() {
		return dateOfTransfer;
	}
	public void setDateOfTransfer(String dateOfTransfer) {
		this.dateOfTransfer = dateOfTransfer;
	}
	public int getTransferAmount() {
		return transferAmount;
	}
	public void setTransferAmount(int transferAmount) {
		this.transferAmount = transferAmount;
	}
	public adminBean3(int fundTransferID, int accountId, int payeeAccountID, String dateOfTransfer,
			int transferAmount) {
		super();
		this.fundTransferID = fundTransferID;
		this.accountId = accountId;
		this.payeeAccountID = payeeAccountID;
		this.dateOfTransfer = dateOfTransfer;
		this.transferAmount = transferAmount;
	}
	public adminBean3() {
		super();
		// TODO Auto-generated constructor stub
	}
	
	
	
	

}
